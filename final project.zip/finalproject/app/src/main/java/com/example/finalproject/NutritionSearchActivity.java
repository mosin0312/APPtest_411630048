package com.example.finalproject;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class NutritionSearchActivity extends AppCompatActivity {

    private EditText editSearch;
    private Button btnSearch;
    private TextView textResult;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_nutrition_search);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 初始化 UI 元件
        editSearch = findViewById(R.id.editSearch);
        btnSearch = findViewById(R.id.btnSearch);
        textResult = findViewById(R.id.textNutritionResult);

        // 初始化資料庫輔助器
        dbHelper = new DatabaseHelper(this);

        // 查詢按鈕點擊事件
        btnSearch.setOnClickListener(v -> {
            String keyword = editSearch.getText().toString().trim();
            if (!keyword.isEmpty()) {
                String result = dbHelper.getNutritionByName(keyword);
                textResult.setText(result);
            } else {
                textResult.setText("請輸入食物名稱");
            }
        });
    }
}
