package com.example.timerapp

import android.os.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var textViewTimer: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var buttonStartFocus: Button
    private lateinit var buttonStartBreak: Button
    private lateinit var buttonStop: Button
    private lateinit var seekBarTime: SeekBar
    private lateinit var textViewSelect: TextView

    private var isRunning = false
    private var totalSeconds = 0
    private var secondsLeft = 0
    private lateinit var handler: Handler
    private var timerThread: Thread? = null
    private var selectedMinutes = 25

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textViewTimer = findViewById(R.id.textViewTimer)
        progressBar = findViewById(R.id.progressBar)
        buttonStartFocus = findViewById(R.id.buttonStartFocus)
        buttonStartBreak = findViewById(R.id.buttonStartBreak)
        buttonStop = findViewById(R.id.buttonStop)
        seekBarTime = findViewById(R.id.seekBarTime)
        textViewSelect = findViewById(R.id.textViewSelect)
        handler = Handler(Looper.getMainLooper())

        // SeekBar 調整時間與預設顯示
        seekBarTime.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                selectedMinutes = if (progress < 1) 1 else progress
                textViewSelect.text = "選擇倒數時間：$selectedMinutes 分鐘"
                textViewTimer.text = String.format(Locale.getDefault(), "%02d:00", selectedMinutes)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                Toast.makeText(this@MainActivity, "你選擇了 $selectedMinutes 分鐘", Toast.LENGTH_SHORT).show()
            }
        })

        // 開始專注按鈕：使用者自訂時間
        buttonStartFocus.setOnClickListener {
            if (!isRunning) {
                startTimer(selectedMinutes * 60)
            }
        }

        // 開始休息按鈕：5 分鐘
        buttonStartBreak.setOnClickListener {
            if (!isRunning) {
                startTimer(5 * 60)
                Toast.makeText(this, "開始 5 分鐘休息", Toast.LENGTH_SHORT).show()
            }
        }

        // 結束倒數按鈕：中斷 + 重設畫面
        buttonStop.setOnClickListener {
            if (isRunning) {
                isRunning = false
                timerThread?.interrupt()
            }

            // 重設畫面狀態
            progressBar.progress = 0
            textViewTimer.text = String.format(Locale.getDefault(), "%02d:00", selectedMinutes)
            Toast.makeText(this, "倒數已結束並重置", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startTimer(durationInSeconds: Int) {
        totalSeconds = durationInSeconds
        secondsLeft = durationInSeconds
        progressBar.max = totalSeconds
        progressBar.progress = 0
        isRunning = true

        timerThread = Thread {
            while (secondsLeft > 0 && isRunning) {
                try {
                    Thread.sleep(1000)
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                    return@Thread // 避免崩潰，正常中止
                }

                secondsLeft--

                handler.post {
                    val minutes = secondsLeft / 60
                    val seconds = secondsLeft % 60
                    textViewTimer.text = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
                    progressBar.progress = totalSeconds - secondsLeft
                }
            }

            if (isRunning) {
                handler.post {
                    isRunning = false
                    textViewTimer.text = "00:00"
                    Toast.makeText(this@MainActivity, "時間結束！", Toast.LENGTH_SHORT).show()
                }
            }
        }

        timerThread?.start()
    }

    override fun onDestroy() {
        isRunning = false
        timerThread?.interrupt()
        super.onDestroy()
    }
}